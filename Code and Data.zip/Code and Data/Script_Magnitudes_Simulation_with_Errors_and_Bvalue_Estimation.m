% Script b-value estimation comparison;
% Figures 2/3 of the paper
% The standard error of the magnitudes is stored in the variables
% "Magn_1" and "Magn_2" (column 3) for each subplot

% number of simulated catalogs
Sim = 10^4 ;

% number of events in each simulated catalog
Num_Ev = 10^4 ;

% starting magnitude for simulations and
% magnitude of completeness for the final selection
Magn_Start = 0 ;
Magn_Compl = 1.0 ;

% b-value for the simulated magnitudes
Bvalue_Sim = 1 ;

%%%%%%%%%%%% subplot 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% magnitude thresholds and relative errors
% Format: Magn Min , Magn Max , Standard Error
Magn_1 = [ Magn_Start     , Magn_Compl + 0.05  , 0.25  ] ;
Magn_2 = [ Magn_Compl + 0.05 , Magn_Compl + 6  , 0.05  ] ;


% magnitude bins
Magn_Bins = Magn_Compl : 0.1 : Magn_Compl + 6 ;

% preallocation of vector and matrix
B_clas    = zeros( Sim , 1 ) ;
Hist_Magn = zeros( Sim , length( Magn_Bins ) - 1 ) ;

% loop 'for' for magnitudes simulation, catalog selection,
% and b-value estimation
for i = 1 : Sim
    
    % magnitudes simulation
    Magn = -1/( Bvalue_Sim*log(10) )*log( rand(Num_Ev,1) ) + Magn_Start ;
    
    % preallocation of the matrix with magnitude and errors
    Magn_Err = zeros( Num_Ev , 2 ) ;
    
    % adding the errors according to the preselected thresholds
    for j = 1 : Num_Ev
       
        if     Magn( j ) >= Magn_1(1) && Magn(j) < Magn_1(2)
            
            Magn_Err( j , 1 ) = Magn( j ) + rand*Magn_1(3) ;
            Magn_Err( j , 2 ) = Magn_1(3) ;
            
        elseif Magn( j ) >= Magn_2(1) && Magn(j) < Magn_2(2)
            
            Magn_Err( j , 1 ) = Magn( j ) + rand*Magn_2(3) ;
            Magn_Err( j , 2 ) = Magn_2(3) ;
        end
        
    end
    
    % select the magnitude above the completeness
    Magn_Ok = Magn_Err( Magn_Err( : , 1 ) >= Magn_Compl , : ) ;
      
    % estimate the b-value
    [ B_clas(i) , N , Sigma ] = BvalueEstimation(   Magn_Ok , 1 , Magn_Compl , 0 ) ;
    
    % count the number of events in each magnitude 0.1 bin:
    Hist_Magn( i , : ) = histcounts( Magn_Ok( : , 1 ) , Magn_Bins ) ;
    
    % show the remaining number of iterations
    Sim - i
end

% plot the results
subplot( 4 , 2 , 1 )
h = histogram( B_clas , 50 ) ;
h.FaceColor = [0.5 0.5 0.5];
xlabel( 'B-value' )
ylabel( 'Frequency' )
hold on
plot( [ Bvalue_Sim , Bvalue_Sim ] , [ 0 , 800 ] , '--k' ) % add the real b-value line

% MFD of the last simulated catalog
subplot( 4 , 2 , 2 )
Incr  = sum( Hist_Magn ) / Sim ;
plot( Magn_Bins( 1 : end - 1 ) , log10( Incr  ) , 'ok' )
xlim( [ 1 , 2.5 ] )
ylim( [ 0.5 , 2.5 ] )
xlabel( 'Magnitude' )
ylabel( 'Log_{10} number of events' )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%% subplot 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% magnitude thresholds and relative errors
% Format: Magn Min , Magn Max , Error
Magn_1 = [ Magn_Start     , Magn_Compl + 0.1  , 0.25  ] ;
Magn_2 = [ Magn_Compl + 0.1 , Magn_Compl + 6  , 0.05  ] ;


% magnitude bins
Magn_Bins = Magn_Compl : 0.1 : Magn_Compl + 6 ;

% preallocation of vector and matrix
B_clas    = zeros( Sim , 1 ) ;
Hist_Magn = zeros( Sim , length( Magn_Bins ) - 1 ) ;

% loop 'for' for magnitudes simulation, catalog selection,
% and b-value estimation
for i = 1 : Sim
    
    % magnitudes simulation
    Magn = -1/( Bvalue_Sim*log(10) )*log( rand(Num_Ev,1) ) + Magn_Start ;
    
    % preallocation of the matrix with magnitude and errors
    Magn_Err = zeros( Num_Ev , 2 ) ;
    
    % adding the errors according to the preselected thresholds
    for j = 1 : Num_Ev
       
        if     Magn( j ) >= Magn_1(1) && Magn(j) < Magn_1(2)
            
            Magn_Err( j , 1 ) = Magn( j ) + rand*Magn_1(3) ;
            Magn_Err( j , 2 ) = Magn_1(3) ;
            
        elseif Magn( j ) >= Magn_2(1) && Magn(j) < Magn_2(2)
            
            Magn_Err( j , 1 ) = Magn( j ) + rand*Magn_2(3) ;
            Magn_Err( j , 2 ) = Magn_2(3) ;
        end
        
    end
    
    % select the magnitude above the completeness
    Magn_Ok = Magn_Err( Magn_Err( : , 1 ) >= Magn_Compl , : ) ;
      
    % estimate the b-value
    [ B_clas(i) , N , Sigma ] = BvalueEstimation(   Magn_Ok , 1 , Magn_Compl , 0 ) ;
    
    % count the number of events in each magnitude 0.1 bin:
    Hist_Magn( i , : ) = histcounts( Magn_Ok( : , 1 ) , Magn_Bins ) ;
    
    % show the remaining number of iterations
    Sim - i
end

% plot the results
subplot( 4 , 2 , 3 )
h = histogram( B_clas , 50 ) ;
h.FaceColor = [0.5 0.5 0.5];
xlabel( 'B-value' )
ylabel( 'Frequency' )
hold on
plot( [ Bvalue_Sim , Bvalue_Sim ] , [ 0 , 800 ] , '--k' ) % add the real b-value line

% MFD of the last simulated catalog
subplot( 4 , 2 , 4 )
Incr  = sum( Hist_Magn ) / Sim ;
plot( Magn_Bins( 1 : end - 1 ) , log10( Incr  ) , 'ok' )
xlim( [ 1 , 2.5 ] )
ylim( [ 0.5 , 2.5 ] )
xlabel( 'Magnitude' )
ylabel( 'Log_{10} number of events' )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%% subplot 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% magnitude thresholds and relative errors
% Format: Magn Min , Magn Max , Error
Magn_1 = [ Magn_Start     , Magn_Compl + 0.5  , 0.25  ] ;
Magn_2 = [ Magn_Compl + 0.5 , Magn_Compl + 6  , 0.05  ] ;


% magnitude bins
Magn_Bins = Magn_Compl : 0.1 : Magn_Compl + 6 ;

% preallocation of vector and matrix
B_clas    = zeros( Sim , 1 ) ;
Hist_Magn = zeros( Sim , length( Magn_Bins ) - 1 ) ;

% loop 'for' for magnitudes simulation, catalog selection,
% and b-value estimation
for i = 1 : Sim
    
    % magnitudes simulation
    Magn = -1/( Bvalue_Sim*log(10) )*log( rand(Num_Ev,1) ) + Magn_Start ;
    
    % preallocation of the matrix with magnitude and errors
    Magn_Err = zeros( Num_Ev , 2 ) ;
    
    % adding the errors according to the preselected thresholds
    for j = 1 : Num_Ev
       
        if     Magn( j ) >= Magn_1(1) && Magn(j) < Magn_1(2)
            
            Magn_Err( j , 1 ) = Magn( j ) + rand*Magn_1(3) ;
            Magn_Err( j , 2 ) = Magn_1(3) ;
            
        elseif Magn( j ) >= Magn_2(1) && Magn(j) < Magn_2(2)
            
            Magn_Err( j , 1 ) = Magn( j ) + rand*Magn_2(3) ;
            Magn_Err( j , 2 ) = Magn_2(3) ;
        end
        
    end
    
    % select the magnitude above the completeness
    Magn_Ok = Magn_Err( Magn_Err( : , 1 ) >= Magn_Compl , : ) ;
      
    % estimate the b-value
    [ B_clas(i) , N , Sigma ] = BvalueEstimation(   Magn_Ok , 1 , Magn_Compl , 0 ) ;
    
    % count the number of events in each magnitude 0.1 bin:
    Hist_Magn( i , : ) = histcounts( Magn_Ok( : , 1 ) , Magn_Bins ) ;
    
    % show the remaining number of iterations
    Sim - i
end

% plot the results
subplot( 4 , 2 , 5 )
h = histogram( B_clas , 50 ) ;
h.FaceColor = [0.5 0.5 0.5];
xlabel( 'B-value' )
ylabel( 'Frequency' )
hold on
plot( [ Bvalue_Sim , Bvalue_Sim ] , [ 0 , 800 ] , '--k' ) % add the real b-value line

% MFD of the last simulated catalog
subplot( 4 , 2 , 6 )
Incr  = sum( Hist_Magn ) / Sim ;
plot( Magn_Bins( 1 : end - 1 ) , log10( Incr  ) , 'ok' )
xlim( [ 1 , 2.5 ] )
ylim( [ 0.5 , 2.5 ] )
xlabel( 'Magnitude' )
ylabel( 'Log_{10} number of events' )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%% subplot 4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% magnitude thresholds and relative errors
% Format: Magn Min , Magn Max , Error
Magn_1 = [ Magn_Start     , Magn_Compl + 1.0  , 0.25  ] ;
Magn_2 = [ Magn_Compl + 1.0 , Magn_Compl + 6  , 0.05  ] ;


% magnitude bins
Magn_Bins = Magn_Compl : 0.1 : Magn_Compl + 6 ;

% preallocation of vector and matrix
B_clas    = zeros( Sim , 1 ) ;
Hist_Magn = zeros( Sim , length( Magn_Bins ) - 1 ) ;

% loop 'for' for magnitudes simulation, catalog selection,
% and b-value estimation
for i = 1 : Sim
    
    % magnitudes simulation
    Magn = -1/( Bvalue_Sim*log(10) )*log( rand(Num_Ev,1) ) + Magn_Start ;
    
    % preallocation of the matrix with magnitude and errors
    Magn_Err = zeros( Num_Ev , 2 ) ;
    
    % adding the errors according to the preselected thresholds
    for j = 1 : Num_Ev
       
        if     Magn( j ) >= Magn_1(1) && Magn(j) < Magn_1(2)
            
            Magn_Err( j , 1 ) = Magn( j ) + rand*Magn_1(3) ;
            Magn_Err( j , 2 ) = Magn_1(3) ;
            
        elseif Magn( j ) >= Magn_2(1) && Magn(j) < Magn_2(2)
            
            Magn_Err( j , 1 ) = Magn( j ) + rand*Magn_2(3) ;
            Magn_Err( j , 2 ) = Magn_2(3) ;
        end
        
    end
    
    % select the magnitude above the completeness
    Magn_Ok = Magn_Err( Magn_Err( : , 1 ) >= Magn_Compl , : ) ;
      
    % estimate the b-value
    [ B_clas(i) , N , Sigma ] = BvalueEstimation(   Magn_Ok , 1 , Magn_Compl , 0 ) ;
    
    % count the number of events in each magnitude 0.1 bin:
    Hist_Magn( i , : ) = histcounts( Magn_Ok( : , 1 ) , Magn_Bins ) ;
    
    % show the remaining number of iterations
    Sim - i
end

% plot the results
subplot( 4 , 2 , 7 )
h = histogram( B_clas , 50 ) ;
h.FaceColor = [0.5 0.5 0.5];
xlabel( 'B-value' )
ylabel( 'Frequency' )
hold on
plot( [ Bvalue_Sim , Bvalue_Sim ] , [ 0 , 800 ] , '--k' ) % add the real b-value line

% MFD of the last simulated catalog
subplot( 4 , 2 , 8 )
Incr  = sum( Hist_Magn ) / Sim ;
plot( Magn_Bins( 1 : end - 1 ) , log10( Incr  ) , 'ok' )
xlim( [ 1 , 2.5 ] )
ylim( [ 0.5 , 2.5 ] )
xlabel( 'Magnitude' )
ylabel( 'Log_{10} number of events' )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
